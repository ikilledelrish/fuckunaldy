package application;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.util.Duration;

public class Controller {

    @FXML
    private TextField minutesField;

    @FXML
    private TextField secondsField;

    @FXML
    private TextField millisecondsField;

    @FXML
    private Button startButton;

    @FXML
    private Button stopButton;

    @FXML
    private Button plusButton;

    @FXML
    private Button minusButton;

    @FXML
    private Button setTimeButton;

    @FXML
    private Button stopButton1; // This is the Reset 14 button

    @FXML
    private Label timerLabel;

    private Timeline timeline;

    public void initialize() {
        // Disable all buttons initially
        disableAllButtons(true);

        // Add listeners to enable/disable buttons based on text fields
        minutesField.textProperty().addListener((observable, oldValue, newValue) -> checkInputFields());
        secondsField.textProperty().addListener((observable, oldValue, newValue) -> checkInputFields());
        millisecondsField.textProperty().addListener((observable, oldValue, newValue) -> checkInputFields());
    }

    private void checkInputFields() {
        boolean disableSetTimeButton = minutesField.getText().isEmpty() || secondsField.getText().isEmpty() || millisecondsField.getText().isEmpty();
        setTimeButton.setDisable(disableSetTimeButton);
    }

    private void disableAllButtons(boolean disable) {
        startButton.setDisable(disable);
        stopButton.setDisable(disable);
        plusButton.setDisable(disable);
        minusButton.setDisable(disable);
        setTimeButton.setDisable(disable);
        stopButton1.setDisable(disable); // Disabling stopButton1
    }

    @FXML
    private void handleSetTimeButton(ActionEvent event) {
        // Get the input values from the text fields
        int minutes = Integer.parseInt(minutesField.getText());
        int seconds = Integer.parseInt(secondsField.getText());
        int milliseconds = Integer.parseInt(millisecondsField.getText());

        // Calculate total milliseconds
        int totalMilliseconds = minutes * 60000 + seconds * 1000 + milliseconds;

        // Display the inputted time on the timerLabel
        timerLabel.setText(String.format("%02d:%02d:%03d", minutes, seconds, milliseconds));

        // Run the countdown timer
        runCountdownTimer(totalMilliseconds);
    }

    private void runCountdownTimer(int totalMilliseconds) {
        timeline = new Timeline(new KeyFrame(Duration.millis(1), new EventHandler<ActionEvent>() {
            int millisecondsRemaining = totalMilliseconds;

            @Override
            public void handle(ActionEvent event) {
                int minutesRemaining = millisecondsRemaining / 60000;
                int secondsRemaining = (millisecondsRemaining % 60000) / 1000;
                int milliseconds = millisecondsRemaining % 1000;

                // Display the remaining time under "Time Remaining"
                timerLabel.setText(String.format("%02d:%02d:%03d", minutesRemaining, secondsRemaining, milliseconds));
                
                millisecondsRemaining--;

                if (millisecondsRemaining < 0) {
                    timeline.stop();
                    // Handle timeout if needed
                }
            }
        }));
        timeline.setCycleCount(totalMilliseconds);
        timeline.play();
    }

    // Add event handlers for button actions (startTimer, stopTimer, etc.)
}
